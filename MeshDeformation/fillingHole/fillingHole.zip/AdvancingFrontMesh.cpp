#include "stdafx.h"
#pragma warning(disable:4351)
#include "AdvancingFrontMesh.h"
#include "../QuadricsFit.h"
#include "../MeshDisplay/MyTriMesh.h"
#include "igl/exact_geodesic.h"
//==================================================OpenMesh=========================
#include <iostream>

// -------------------- OpenMesh
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/PolyMesh_ArrayKernelT.hh>
 // -------------------- OpenMesh

 //--------------------- allquadrics
#include <fstream>
#include <map>
 //--------------------- allquadrics
#include <numeric>
#include "../Utility/MeshLaplacianSolver.h"
#include <igl/list_to_matrix.h>
#include "../MeshDeform/PoissonDeform/PoissonDeformation.h"
#ifdef _DEBUG
//#define LOOP_DEBUG
#endif
#ifdef LOOP_DEBUG

#define debug_msg(msg) cout << msg <<endl
#define loop_confirm() debug_msg("right loop confirm")
#define loop_abnormal() debug_msg("Error : loop abnormal")

#else

#define debug_msg(msg)
#define loop_confirm()
#define loop_abnormal()

#endif


using namespace allquadrics;
using namespace std;

extern "C" { FILE __iob_func[3] = { *stdin,*stdout,*stderr }; }

bool cmpSecond(pair<int, double>& a, pair<int, double>& b)
{
	return a.second < b.second;
}

TriMesh mesh;
vector<UnitHole> Unit_holes;

//-------------------------------------------------------------------------------------------------


//#define M_PI 3.14159
vec3 crossProductFunc(vec3 v1, vec3 v2)
{
	return vec3
	(
		v1[1] * v2[2] - v1[2] * v2[1],
		v1[2] * v2[0] - v1[0] * v2[2],
		v1[0] * v2[1] - v1[1] * v2[0]
	);
}

double dotProductFunc(vec3 v1, vec3 v2)
{
	double sum = 0.0;

	sum += v1[0] * v2[0];
	sum += v1[1] * v2[1];
	sum += v1[2] * v2[2];

	return sum;
}


void saveMesh(TriMesh mesh, string name, bool resultSave)
{
	try
	{
		if (resultSave)
		{
			if (!OpenMesh::IO::write_mesh(mesh, "Result/" + name + ".obj"))
			{
				std::cerr << "Cannot write mesh to file 'output.off'" << std::endl;
			}
		}
		else
		{
			if (!OpenMesh::IO::write_mesh(mesh, "Log/" + name + ".obj"))
			{
				std::cerr << "Cannot write mesh to file 'output.off'" << std::endl;
			}
		}

		std::cout << "Save Complete" << endl;
	}
	catch (std::exception& x)
	{
		std::cerr << x.what() << std::endl;
	}
}



// calc edges average length
double edgeLengthAverage(TriMesh& mesh)
{
	int count = 0;
	double edge_length_average = 0;

	for (auto it = mesh.edges_begin(); it != mesh.edges_end(); it++)
	{
		edge_length_average += mesh.calc_edge_length(*it);
		count++;
	}

	return edge_length_average /= count;
}

// set Original Vertices, Face handles
void setIsOriginalVertexArray(TriMesh& mesh, map<int, bool>& isOriginal_Vertex)
{
	for (auto it = mesh.vertices_begin(); it != mesh.vertices_end(); it++)
	{
		isOriginal_Vertex[it->idx()] = true;
	}
}
void setIsOriginalFaceArray(TriMesh& mesh, map<int, bool>& isOriginal_Face)
{
	for (auto it = mesh.faces_begin(); it != mesh.faces_end(); it++)
	{
		isOriginal_Face[it->idx()] = true;
	}
}

// find boundary vertices and sort loop
void boundaryVertexSort(TriMesh mesh, vector<TriMesh::VertexHandle> vhandle_boundary, vector<pair<TriMesh::VertexHandle, TriMesh::Point>>& holes, vector<TriMesh::VertexHandle>& second_hole)
{
	holes.clear();

	if (vhandle_boundary.empty())
		return;

	holes.push_back(make_pair(vhandle_boundary[0], mesh.point(vhandle_boundary[0])));
	auto vertex_startPoint = vhandle_boundary[0];
	auto vertex_tmp = vhandle_boundary[0];
	TriMesh::HalfedgeHandle connected_halfEdge = mesh.halfedge_handle(vertex_tmp);
	TriMesh::VertexHandle next_v = mesh.to_vertex_handle(connected_halfEdge);
	vhandle_boundary.erase(vhandle_boundary.begin());

	while (!vhandle_boundary.empty())
	{
		if (vhandle_boundary.size() == 1)
		{
			vertex_tmp = vhandle_boundary[0];
			if (vertex_tmp.idx() == next_v.idx())
			{
				holes.push_back(make_pair(vertex_tmp, mesh.point(vertex_tmp)));

				connected_halfEdge = mesh.halfedge_handle(vertex_tmp);
				next_v = mesh.to_vertex_handle(connected_halfEdge);


				if (next_v.idx() == vertex_startPoint.idx())
				{
					loop_confirm();
				}
				else
				{
					loop_abnormal();
					break;
				}
				return;
			}
			else
			{
				auto p = mesh.point(vertex_tmp);

				loop_abnormal();

				break;
			}
		}

		auto target_it = find(vhandle_boundary.begin(), vhandle_boundary.end(), next_v);

		if (target_it == vhandle_boundary.end() && next_v == vertex_startPoint)
		{
			//cout << "������ 2�� �̻���, ���� vertex���� �ٸ� ������ vertex" << endl;
			second_hole = vhandle_boundary; // ���� �ٸ� ������ vertex���� ���� ����
			vhandle_boundary.clear();
		}
		else if (target_it == vhandle_boundary.end()) {
			cout << "next_v��ã��";
		}
		else
		{
			holes.push_back(make_pair(*target_it, mesh.point(*target_it)));
			vertex_tmp = *target_it;

			connected_halfEdge = mesh.halfedge_handle(vertex_tmp);
			next_v = mesh.to_vertex_handle(connected_halfEdge);

			vhandle_boundary.erase(target_it);
		}
	}
}
void boundaryUpdate(TriMesh& mesh, vector<pair<TriMesh::VertexHandle, TriMesh::Point>>& holes, vector<TriMesh::VertexHandle>& second_hole)
{
	vector<TriMesh::VertexHandle> vhandle_boundary;

	if (holes.size() <= 2)	// �� ������ vertex�� 2�� ������ ��� => ��ä�� ����̹Ƿ� ���� �������� �Ѿ
	{
		for (int i = 0; i < second_hole.size(); i++)
		{
			if (mesh.is_valid_handle(second_hole[i]) && mesh.is_boundary(second_hole[i]))
			{
				vhandle_boundary.push_back(second_hole[i]);
			}
		}

		second_hole.clear(); // �� ä���־����� clear
	}
	else // 2�� �̻��� ���� ���� ���� vertex�� ���������Ƿ� �ش� ���ۿ��� �˻�
	{
		for (int i = 0; i < holes.size(); i++)
		{
			if (mesh.is_valid_handle(holes[i].first) && mesh.is_boundary(holes[i].first))
			{
				vhandle_boundary.push_back(holes[i].first);
			}
		}
	}

	boundaryVertexSort(mesh, vhandle_boundary, holes, second_hole);
}

double calcSectorAngleUseQaudrics(TriMesh& mesh, TriMesh::HalfedgeHandle _in_heh, vec3 normal)
{
	TriMesh::Normal v0, v1;
	TriMesh::Normal f_n(normal[0], normal[1], normal[2]);
	mesh.calc_sector_vectors(_in_heh, v0, v1);

	TriMesh::Scalar a = norm(v0);
	TriMesh::Scalar b = norm(v1);

	TriMesh::Scalar denom = norm(v0) * norm(v1);
	if (denom == TriMesh::Scalar(0))
	{
		return 0;
	}
	TriMesh::Scalar cos_a = dot(v0, v1) / denom;
	if (mesh.is_boundary(_in_heh))
	{
		TriMesh::Scalar sign_a = dot(cross(v0, v1), f_n);
		return OpenMesh::angle(cos_a, sign_a);
	}
	else
	{
		if (cos_a < -1)
			cos_a = -1;
		if (cos_a > 1)
			cos_a = 1;

		return acos(cos_a);
	}
}

// calc vertices angles and sort
double calcAngle(TriMesh& mesh, TriMesh::VertexHandle vh)
{
	int idx = vh.idx();

	double deg;

	TriMesh::HalfedgeHandle prev_halfedge = mesh.prev_halfedge_handle(mesh.halfedge_handle(vh));

	deg = mesh.calc_sector_angle(prev_halfedge) * 180 / M_PI;

	if (deg < 0) {
		deg += 360;
		assert(0);
	}

	return deg;
}

void angleUpdate(TriMesh& mesh, vector<pair<TriMesh::VertexHandle, TriMesh::Point>>& holes, int &minAngleVertexIndex, vector<double>& angles)
{
	float minAngle = 360;
	angles.clear();
	mesh.request_face_normals();

	for (int i = 0; i < holes.size(); i++)
	{
		double angle = calcAngle(mesh, holes[i].first);
		angles.push_back(angle);
		if (angle < minAngle) {
			minAngle = angle;
			minAngleVertexIndex = i;
		}
	}
}

// merge close vertices
bool isCloseOtherVertexExist(vector<pair<TriMesh::VertexHandle, TriMesh::Point>>& holes, int a, int b)
{
	TriMesh::Point va1; // a ���� vertex Point
	TriMesh::Point va2; // a ���� vertex Point
	TriMesh::Point vb1; // b ���� vertex Point
	TriMesh::Point vb2; // b ���� vertex Point

	TriMesh::Point va = holes[a].second;
	TriMesh::Point vb = holes[b].second;

	double interval = sqrt(pow((va[0] - vb[0]), 2) + pow((va[1] - vb[1]), 2) + pow((va[2] - vb[2]), 2));

	va1 = a == 0 ? holes[holes.size() - 1].second : holes[a - 1].second;
	va2 = a == holes.size() - 1 ? holes[0].second : holes[a + 1].second;
	vb1 = b == 0 ? holes[holes.size() - 1].second : holes[b - 1].second;
	vb2 = b == holes.size() - 1 ? holes[0].second : holes[b + 1].second;

	vector<double> cmp_intervals;

	cmp_intervals.push_back(sqrt(pow((va[0] - vb1[0]), 2) + pow((va[1] - vb1[1]), 2) + pow((va[2] - vb1[2]), 2)));
	cmp_intervals.push_back(sqrt(pow((va[0] - vb2[0]), 2) + pow((va[1] - vb2[1]), 2) + pow((va[2] - vb2[2]), 2)));
	cmp_intervals.push_back(sqrt(pow((vb[0] - va1[0]), 2) + pow((vb[1] - va1[1]), 2) + pow((vb[2] - va1[2]), 2)));
	cmp_intervals.push_back(sqrt(pow((vb[0] - va2[0]), 2) + pow((vb[1] - va2[1]), 2) + pow((vb[2] - va2[2]), 2)));

	for (double i : cmp_intervals)
	{
		if (i <= interval)
		{
			return true;
		}
	}

	return false;
}
void fillTrianglesAfterMerge(TriMesh& mesh, TriMesh::VertexHandle currentVh)
{
	TriMesh::HalfedgeHandle prev_halfedge = mesh.halfedge_handle(currentVh);

	vector<TriMesh::VertexHandle> TrianglePoints;

	int count = 0;

	while (count < 2)
	{
		prev_halfedge = mesh.prev_halfedge_handle(prev_halfedge);
		TriMesh::VertexHandle targetVh = mesh.from_vertex_handle(prev_halfedge);

		if (targetVh == currentVh)
		{
			TrianglePoints.push_back(mesh.to_vertex_handle(prev_halfedge));
			TrianglePoints.push_back(mesh.from_vertex_handle(mesh.prev_halfedge_handle(mesh.halfedge_handle(currentVh))));
			TrianglePoints.push_back(currentVh);

			mesh.add_face(TrianglePoints);

			TrianglePoints.clear();

			prev_halfedge = mesh.halfedge_handle(currentVh);

			count++;
		}
	}
}
void mergeCloseVertex(TriMesh& mesh, vector<pair<TriMesh::VertexHandle, TriMesh::Point>>& holes, map<int, bool> isOriginal_Vertex, double edge_length_average, int k, bool useQuadrics, QuadricsFit q)
{
	for (int i = 0; i < holes.size(); i++)
	{
		vec3 p1(holes[i].second[0], holes[i].second[1], holes[i].second[2]);

		for (int j = 0; j < holes.size(); j++)
		{
			if (holes.size() > 5)
			{
				if (((i - j + holes.size()) % holes.size() <= 2) || ((j - i + holes.size()) % holes.size() <= 2))
					continue;
			}
			else
			{
				if (((i - j + holes.size()) % holes.size() <= 1) || ((j - i + holes.size()) % holes.size() <= 1))
					continue;
			}

			vec3 p2(holes[j].second[0], holes[j].second[1], holes[j].second[2]);

			double interval = sqrt(pow((p1[0] - p2[0]), 2) + pow((p1[1] - p2[1]), 2) + pow((p1[2] - p2[2]), 2));

			TriMesh::HalfedgeHandle hh1 = mesh.find_halfedge(holes[i].first, holes[j].first);
			TriMesh::HalfedgeHandle hh2 = mesh.find_halfedge(holes[j].first, holes[i].first);

			if (interval < edge_length_average && !isOriginal_Vertex[holes[j].first.idx()] && !isOriginal_Vertex[holes[i].first.idx()]
				&& hh1 == TriMesh::InvalidHalfedgeHandle && hh2 == TriMesh::InvalidHalfedgeHandle && !isCloseOtherVertexExist(holes, i, j))
			{
				vec3 center_coord((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2, (p1[2] + p2[2]) / 2);

				if (useQuadrics)
					center_coord = q.calcTargetPoint(center_coord);

				TriMesh::Point p_new(center_coord[0], center_coord[1], center_coord[2]);

				mesh.set_point(holes[j].first, p_new);

				vector<vector<TriMesh::VertexHandle>> triangle_Points;

				for (auto it = mesh.vf_begin(holes[i].first); it != mesh.vf_end(holes[i].first); it++)	// merge vertices
				{
					TriMesh::FaceHandle fh = it;
					vector<TriMesh::VertexHandle> tmp;
					for (auto it_f = mesh.fv_begin(fh); it_f != mesh.fv_end(fh); it_f++)
					{
						if (*it_f == holes[i].first) ///???
							tmp.push_back(holes[j].first);
						else
							tmp.push_back(it_f);
					}
					triangle_Points.push_back(tmp);
					tmp.clear();
				}

				mesh.request_face_status();
				mesh.request_edge_status();
				mesh.request_vertex_status();

				auto it = holes.begin() + i;
				TriMesh::VertexHandle target = holes[i].first;
				TriMesh::VertexHandle merge_vh = holes[j].first;

				holes.erase(it);

				mesh.delete_vertex(target);

				for (auto vh : triangle_Points)
				{
					vector<TriMesh::VertexHandle> tmp;
					for (auto v : vh)
					{
						tmp.push_back(v);
					}

					mesh.add_face(tmp);
					tmp.clear();
				}

				fillTrianglesAfterMerge(mesh, merge_vh);

				mesh.garbage_collection();

				mesh.request_face_status();
				mesh.request_edge_status();
				mesh.request_vertex_status();

				//save(mesh, "after_merge_" + to_string(k));

				return;
			}
		}
	}
}


#define SKIP_SIZE  20

vec3 oneRingNormal(TriMesh& mesh, TriMesh::VertexHandle vh)
{
	TriMesh::Normal ret(0);

	for (auto it = mesh.vf_begin(vh); it != mesh.vf_end(vh); it++) {
		ret += mesh.normal(*it);
	}
	ret.normalize();
	return vec3(ret[0], ret[1], ret[2]);
}
// fill hole
void fillHoleMain(TriMesh& mesh_findBoundary, vector<pair<TriMesh::VertexHandle, TriMesh::Point>> holes, vector< double> angles, int minAngleVertexIndex, 
	map<int, bool> isOriginal_Vertex, double edge_length_average, QuadricsFit q, bool useQuadrics)
{
	vector<vector<TriMesh::VertexHandle>> triangle_Points;
	vector<TriMesh::VertexHandle> second_hole;
	int nSkip = SKIP_SIZE;
	int k = 0;
	bool save = false;
	while (!holes.empty())
	{
		mesh_findBoundary.update_face_normals();
		if((holes.size() - 1) / 4 < nSkip)
			nSkip = (int)(holes.size() - 1) / 4;
		

		if (k % 100 == 0) //|| (k<70 && k>60)  )
		//if(save)
		{

			string msg = "���� �� : " + to_string(k) + "��° �ݺ� ����";
			debug_msg(msg);
			save = false;
			mesh_findBoundary.garbage_collection();

			saveMesh(mesh_findBoundary, to_string(k));
		}
		
		
		if (holes.size() < 3)
		{
			break;
		}

		int index = minAngleVertexIndex;	// ���̰��� ���� ���� ��ü(�������� ������ 0��°)
		vector<TriMesh::VertexHandle> tmp;
		vec3 index_vec(holes[index].second[0], holes[index].second[1], holes[index].second[2]);
		bool newVertexCreated;


		if (angles[index] <= 75 || angles[index]+angles[(index+1)%holes.size()] <=180 || angles[index]+angles[(index-1+holes.size())%holes.size()] <=180) // 75���� ���� ���� ��� -> �� 0�� �߰�, �� 1�� ����, �ﰢ�� 1�� �߰�
		{
			if (index == 0)
			{
				tmp.push_back(holes[holes.size() - 1].first);
			}
			else
			{
				tmp.push_back(holes[index - 1].first);
			}

			tmp.push_back(holes[index].first);

			if (index == holes.size() - 1)
			{
				tmp.push_back(holes[0].first);
			}
			else
			{
				tmp.push_back(holes[index + 1].first);
			}

			triangle_Points.push_back(tmp); // �ﰢ�� �߰�

			holes.erase(find(holes.begin(), holes.end(), holes[index]));

			newVertexCreated = false;
		}

		else if (75 < angles[index] && angles[index] <= 135.1) // 75 < ���̰� < 135 �� ��� -> �� 1�� �߰�, �� 1�� ����, �ﰢ�� 2�� �߰�
		{
			vec3 a;
			if (index == 0)
			{
				a[0] = holes[holes.size() - 1].second[0];
				a[1] = holes[holes.size() - 1].second[1];
				a[2] = holes[holes.size() - 1].second[2];

				tmp.push_back(holes[holes.size() - 1].first);
			}
			else
			{
				a[0] = holes[index - 1].second[0];
				a[1] = holes[index - 1].second[1];
				a[2] = holes[index - 1].second[2];

				tmp.push_back(holes[index - 1].first);
			}

			vec3 b;
			if (index == holes.size() - 1)
			{
				b[0] = holes[0].second[0];
				b[1] = holes[0].second[1];
				b[2] = holes[0].second[2];
			}
			else
			{
				b[0] = holes[index + 1].second[0];
				b[1] = holes[index + 1].second[1];
				b[2] = holes[index + 1].second[2];
			}

		
			vec3 a1;
			if (index < nSkip)
			{
				a1[0] = holes[holes.size() + index - nSkip].second[0];
				a1[1] = holes[holes.size() + index - nSkip].second[1];
				a1[2] = holes[holes.size() + index - nSkip].second[2];

				
			}
			else
			{
				a1[0] = holes[index - nSkip].second[0];
				a1[1] = holes[index - nSkip].second[1];
				a1[2] = holes[index - nSkip].second[2];

				
			}
			vec3 b1;
			if (index >= holes.size() - nSkip)
			{
				b1[0] = holes[index - holes.size() + nSkip].second[0];
				b1[1] = holes[index - holes.size() + nSkip].second[1];
				b1[2] = holes[index - holes.size() + nSkip].second[2];
			}
			else
			{
				b1[0] = holes[index + nSkip].second[0];
				b1[1] = holes[index + nSkip].second[1];
				b1[2] = holes[index + nSkip].second[2];
			}
			vec3 v1 = a - index_vec;
			vec3 v2 = b - index_vec;
			vec3 v11 = a1 - index_vec;
			vec3 v22 = b1 - index_vec;
			
			vec3 large_area_norm = crossProductFunc(v11, v22);
			float weight = 1- abs(dotProductFunc(v11.normalize(), v22.normalize()));
			large_area_norm.normalize();

			vec3 ringNormal = oneRingNormal(mesh_findBoundary, holes[index].first);

			vec3 new_normal = large_area_norm * weight + ringNormal * (1 - weight);
			
			vec3 new_vec = v1 + v2; // ���ο� �� ��ǥ (a ���� + b ����)

			new_vec.normalize();
			vec3 new_vec1 = new_vec - (new_vec * new_normal) * new_normal;
			new_vec1.normalize();
			
			new_vec *= max(edge_length_average, ((v1.length() + v2.length()) / 2));

			vec3 new_coord = index_vec + new_vec;

			if (useQuadrics && holes.size() > 10)
				new_coord = q.calcTargetPoint(new_coord);	// calc quadrics

			TriMesh::Point new_point(new_coord[0], new_coord[1], new_coord[2]);

			TriMesh::VertexHandle vh_tmp = mesh_findBoundary.add_vertex(new_point); // ���ο� �� ����

			tmp.push_back(holes[index].first);
			tmp.push_back(vh_tmp);
			triangle_Points.push_back(tmp); // �ﰢ�� 1 �߰�

			tmp.clear();
			tmp.push_back(vh_tmp);
			tmp.push_back(holes[index].first);

			if (index == holes.size() - 1)
				tmp.push_back(holes[0].first);
			else
				tmp.push_back(holes[index + 1].first);

			triangle_Points.push_back(tmp); // �ﰢ�� 2 �߰�

			holes[index] = make_pair(vh_tmp, new_point);// �ﰢ�� �߰������� holes�� angle�� ���� �� ������ �ٲٱ�

			newVertexCreated = true;
		}

		else // 135 < ���̰� �� ��� -> �� 2�� �߰�, �� 1�� ����, �ﰢ�� 3�� �߰�
		{

		save = true;
			vec3 a;
			if (index == 0)
			{
				a[0] = holes[holes.size() - 1].second[0];
				a[1] = holes[holes.size() - 1].second[1];
				a[2] = holes[holes.size() - 1].second[2];

				tmp.push_back(holes[holes.size() - 1].first);
			}
			else
			{
				a[0] = holes[index - 1].second[0];
				a[1] = holes[index - 1].second[1];
				a[2] = holes[index - 1].second[2];

				tmp.push_back(holes[index - 1].first);
			}
			vec3 b;
			if (index == holes.size() - 1)
			{
				b[0] = holes[0].second[0];
				b[1] = holes[0].second[1];
				b[2] = holes[0].second[2];
			}
			else
			{
				b[0] = holes[index + 1].second[0];
				b[1] = holes[index + 1].second[1];
				b[2] = holes[index + 1].second[2];
			}
			vec3 a2;
			if (index < nSkip)
			{
				a2[0] = holes[holes.size() + index - nSkip].second[0];
				a2[1] = holes[holes.size() + index - nSkip].second[1];
				a2[2] = holes[holes.size() + index - nSkip].second[2];

				
			}
			else
			{
				a2[0] = holes[index - nSkip].second[0];
				a2[1] = holes[index - nSkip].second[1];
				a2[2] = holes[index - nSkip].second[2];

				
			}
			vec3 b2;
			if (index >= holes.size() - nSkip)
			{
				b2[0] = holes[index - holes.size() + nSkip].second[0];
				b2[1] = holes[index - holes.size() + nSkip].second[1];
				b2[2] = holes[index - holes.size() + nSkip].second[2];
			}
			else
			{
				b2[0] = holes[index + nSkip].second[0];
				b2[1] = holes[index + nSkip].second[1];
				b2[2] = holes[index + nSkip].second[2];
			}
			vec3 v11 = a2 - index_vec;
			vec3 v22 = b2 - index_vec;
			vec3 large_area_norm = crossProductFunc(v11, v22);
			float weight = 1-abs(dotProductFunc(v11.normalize(), v22.normalize()));
			large_area_norm.normalize();


			vec3 v1 = a - index_vec;
			vec3 v2 = b - index_vec;
			vec3 center_coord = v1 + v2;
			vec3 ringNormal = oneRingNormal(mesh_findBoundary, holes[index].first);

			vec3 new_normal = large_area_norm * weight + ringNormal * (1 - weight);
			center_coord.normalize();

			center_coord = center_coord * ((v1.length() + v2.length()) / 2); //center coord = v1�� v2�� ����

			vec3 a1 = (v1 + center_coord * 2).normalize();// *(v1.length() + center_coord.length() * 2) / 3;
			vec3 b1 = (center_coord * 2 + v2).normalize();// *(center_coord.length() * 2 + v2.length()) / 3;
			a1 = a1 - (a1 * new_normal) * new_normal;
			b1 = b1 - (b1 * new_normal) * new_normal;
			
			a1.normalize();
			b1.normalize();
			a1 *= max(edge_length_average, (v1.length() + center_coord.length() * 2) / 3);
			b1 *= max(edge_length_average, (center_coord.length() * 2 + v2.length()) / 3);

			a1 += index_vec;
			b1 += index_vec;

			if (useQuadrics && holes.size() > 10)
			{
				a1 = q.calcTargetPoint(a1);	// calc quadrics
				b1 = q.calcTargetPoint(b1);
			}

			TriMesh::Point new_Point_a(a1[0], a1[1], a1[2]);
			TriMesh::Point new_Point_b(b1[0], b1[1], b1[2]);

			TriMesh::VertexHandle vh_tmp_a = mesh_findBoundary.add_vertex(new_Point_a);
			TriMesh::VertexHandle vh_tmp_b = mesh_findBoundary.add_vertex(new_Point_b);

			tmp.push_back(holes[index].first);
			tmp.push_back(vh_tmp_a);
			triangle_Points.push_back(tmp);	// �ﰢ�� 1 �߰�

			tmp.clear();
			tmp.push_back(vh_tmp_a);
			tmp.push_back(holes[index].first);
			tmp.push_back(vh_tmp_b);
			triangle_Points.push_back(tmp); // �ﰢ�� 2 �߰�

			tmp.clear();
			tmp.push_back(vh_tmp_b);
			tmp.push_back(holes[index].first);

			if (index == holes.size() - 1)
			{
				tmp.push_back(holes[0].first);
			}
			else
			{
				tmp.push_back(holes[index + 1].first);
			}

			triangle_Points.push_back(tmp);	// �ﰢ�� 3 �߰�

			holes.insert(holes.begin() + index, make_pair(vh_tmp_b, new_Point_b)); // ���ο� point2 �߰�
			holes.insert(holes.begin() + index, make_pair(vh_tmp_a, new_Point_a));	// ���ο� point1 �߰�
			holes.erase(holes.begin() + index + 2); // point ����

			newVertexCreated = true;
		}

		//--------------------------------------------------- vertex���� �̾ ������ �����
		for (int i = 0; i < triangle_Points.size(); i++)
		{
			vector<TriMesh::VertexHandle> face_h;

			for (int j = 0; j < triangle_Points[i].size(); j++)
			{
				face_h.push_back(triangle_Points[i][j]);
			}

			mesh_findBoundary.add_face(face_h);
		}
		//--------------------------------------------------- vertex���� �̾ ������ �����


		triangle_Points.clear();
		tmp.clear();

		//save(mesh_findBoundary, to_string(k));
		if (newVertexCreated)
			mergeCloseVertex(mesh_findBoundary, holes, isOriginal_Vertex, edge_length_average, k, useQuadrics, q);

		boundaryUpdate(mesh_findBoundary, holes, second_hole);
		angleUpdate(mesh_findBoundary, holes, minAngleVertexIndex, angles);

		k++;

		mesh_findBoundary.garbage_collection();

	}
}

// find new vertices, faces after fill hole process
bool isOtherHoleVertex(TriMesh::VertexHandle vh, int targethole_index, vector<UnitHole> unit_holes)
{
	for (int i = 0; i < unit_holes.size(); i++)
	{
		if (i == targethole_index)
			continue;

		for (auto v : unit_holes[i].new_Vertices)
		{
			if (vh == v)
				return true;
		}
	}

	return false;
}
bool isOtherHoleFace(TriMesh::FaceHandle fh, int targethole_index, vector<UnitHole> unit_holes)
{
	for (int i = 0; i < unit_holes.size(); i++)
	{
		if (i == targethole_index)
			continue;

		for (auto f : unit_holes[i].new_Faces)
		{
			if (fh == f)
				return true;
		}
	}

	return false;
}
vector<TriMesh::VertexHandle> findNewVertices(TriMesh& mesh, UnitHole hole, vector<UnitHole> unit_holes, map<int, bool> isOriginal_Vertex)
{
	vector<TriMesh::VertexHandle> newVertexHandles;


	int temp=0;
	for (auto it = mesh.vertices_begin(); it != mesh.vertices_end(); it++)
	{
		if (isOriginal_Vertex[it->idx()] || isOtherHoleVertex(it, hole.hole_number, unit_holes))
			continue;
		else
			newVertexHandles.push_back(*it);
		bool isValid = mesh.is_valid_handle(*it);
		if (!isValid)
			temp++;
	}

	return newVertexHandles;
}
vector<TriMesh::FaceHandle> findNewFaces(TriMesh& mesh, UnitHole hole, vector<UnitHole> unit_holes, map<int, bool> isOriginal_Face)
{
	vector<TriMesh::FaceHandle> newFaceHandles;

	for (auto it = mesh.faces_begin(); it != mesh.faces_end(); it++)
	{
		if (isOriginal_Face[it->idx()] || isOtherHoleFace(it, hole.hole_number, unit_holes))
			continue;
		else
			newFaceHandles.push_back(*it);
	}

	return newFaceHandles;
}

// find all holes
vector<TriMesh::VertexHandle> OriginalBoundaryVertexSort(TriMesh& mesh, vector<TriMesh::VertexHandle>& vhandle_boundary, vector<TriMesh::FaceHandle>& fhandle_boundary)
{
	vector<TriMesh::VertexHandle> hole_vertices;

	hole_vertices.push_back(vhandle_boundary[0]);
	auto vertex_startPoint = vhandle_boundary[0];
	auto vertex_tmp = vhandle_boundary[0];
	TriMesh::HalfedgeHandle connected_halfedge = mesh.halfedge_handle(vertex_tmp);
	TriMesh::VertexHandle next_v = mesh.to_vertex_handle(connected_halfedge);
	vhandle_boundary.erase(vhandle_boundary.begin());
	

	while (true)
	{
		auto target_it = find(vhandle_boundary.begin(), vhandle_boundary.end(), next_v);
		fhandle_boundary.push_back(mesh.face_handle(mesh.opposite_halfedge_handle(connected_halfedge)));

		if (target_it == vhandle_boundary.end() && next_v == vertex_startPoint)
		{
			//cout << "������ 2�� �̻���, ���� vertex���� �ٸ� ������ vertex" << endl;
			return hole_vertices;
		}
		else
		{
			hole_vertices.push_back(*target_it);
			vertex_tmp = *target_it;


			connected_halfedge = mesh.halfedge_handle(vertex_tmp);
			next_v = mesh.to_vertex_handle(connected_halfedge);

			vhandle_boundary.erase(target_it);
		}

	}
}

void statusSettings(TriMesh& mesh)
{
	mesh.request_face_status();
	mesh.request_edge_status();
	mesh.request_vertex_status();
	mesh.request_halfedge_status();

	mesh.update_normals();
}

void eraseFaceHasTwoHalfEdgeBoundary(TriMesh& mesh)
{
	statusSettings(mesh);

	vector<TriMesh::FaceHandle> fh_tmp;

	for (auto it = mesh.faces_begin(); it != mesh.faces_end(); it++)
	{
		int cnt = 0;

		for (auto it_he = mesh.fh_begin(it); it_he != mesh.fh_end(it); it_he++)
		{
			if (mesh.is_boundary(mesh.opposite_halfedge_handle(it_he)))
			{
				cnt++;
			}
		}

		if (cnt > 1)
		{
			cout << "EraseFace" << endl;
			fh_tmp.push_back(it);
		}
	}

	for (int i = 0; i < fh_tmp.size(); i++)
	{
		mesh.delete_face(fh_tmp[i]);
	}

	mesh.garbage_collection();
}


vector<UnitHole> findAllUnitHole(TriMesh& mesh)
{
	vector<UnitHole> vec_tmp;
	vector<TriMesh::VertexHandle> vhandle_boundary;
	vector<TriMesh::FaceHandle> fhandle_boundary;
	vector<TriMesh::VertexHandle> vhandle_tmp;
	int hole_number = 0;


	for (auto it = mesh.vertices_begin(); it != mesh.vertices_end(); it++)
	{
		if (mesh.is_boundary(it))
			vhandle_boundary.push_back(*it);
	}

	while (!vhandle_boundary.empty())
	{
		fhandle_boundary.clear();
		vhandle_tmp = OriginalBoundaryVertexSort(mesh, vhandle_boundary, fhandle_boundary);
		UnitHole uh_tmp;

		for (auto vh : vhandle_tmp)
		{
			TriMesh::Normal vertex_normal = mesh.normal(vh);

			uh_tmp.original_vertices_normals.push_back(make_pair(vh, vertex_normal));
			uh_tmp.hole_original_vertices.push_back(make_pair(vh, mesh.point(vh)));
		}

		uh_tmp.original_Faces = fhandle_boundary;

		angleUpdate(mesh, uh_tmp.hole_original_vertices, uh_tmp.minAngleVertexIndex, uh_tmp.angles);

		uh_tmp.hole_number = hole_number;
		uh_tmp.is_filled = false;

		vec_tmp.push_back(uh_tmp);

		cout << "ã�� ���� index : " << hole_number << endl;

		hole_number++;
	}

	return vec_tmp;
}

void findInvalidVertices(TriMesh& mesh, UnitHole& hole)
{
	mesh.request_vertex_status();
	mesh.request_face_status();

	for (int i = 0; i < hole.new_Vertices.size(); i++)
	{
		if (!mesh.is_valid_handle(hole.new_Vertices[i])) {
			hole.new_Vertices.erase(hole.new_Vertices.begin() + i);
			i--;
		}
		else if(mesh.is_boundary(hole.new_Vertices[i]))
		{
			mesh.delete_vertex(hole.new_Vertices[i]);
			hole.new_Vertices.erase(hole.new_Vertices.begin() + i);
			i--;

			mesh.garbage_collection();
		}
	}

}


AdvancingFrontMesh::AdvancingFrontMesh(TriMesh _mesh)
{
	mesh = _mesh;
	mesh.garbage_collection();
}

void AdvancingFrontMesh::findAllUnitHoles()
{
	mesh.garbage_collection();

	statusSettings(mesh);

	eraseFaceHasTwoHalfEdgeBoundary(mesh);

	statusSettings(mesh);

	Unit_holes = findAllUnitHole(mesh);
	for (int i=0; i < Unit_holes.size(); i++)
		Unit_holes[i].eraseDuplicateOriginalFaces();

	statusSettings(mesh);
}

void AdvancingFrontMesh::fillAllHoles()
{
	map<int, bool> isOriginal_Vertex;
	map<int, bool> isOriginal_Face;
	double length_average = 0;

	setIsOriginalVertexArray(mesh, isOriginal_Vertex); // set Original Vertices
	setIsOriginalFaceArray(mesh, isOriginal_Face); // set Original Faces
	length_average = edgeLengthAverage(mesh); // calc edges average length

	int filled_hole_count = 0;

	for(int targethole_index = 0; targethole_index < Unit_holes.size(); targethole_index++)
	{
		QuadricsFit q;

		fillHoleMain(mesh, Unit_holes[targethole_index].hole_original_vertices,
			Unit_holes[targethole_index].angles, Unit_holes[targethole_index].minAngleVertexIndex, isOriginal_Vertex, length_average, q, false);

		Unit_holes[targethole_index].new_Vertices = findNewVertices(mesh, Unit_holes[targethole_index], Unit_holes, isOriginal_Vertex);
		Unit_holes[targethole_index].new_Faces = findNewFaces(mesh, Unit_holes[targethole_index], Unit_holes, isOriginal_Face);

		findInvalidVertices(mesh, Unit_holes[targethole_index]);

		Unit_holes[targethole_index].is_filled = true;
		filled_hole_count++;

		mesh.garbage_collection();
		saveMesh(mesh, "fillHole_result_" + to_string(targethole_index) + "_fillhole", true); // save result

	}

	std::cout << "fillAllHoles �۾� �Ϸ�" << endl;
}

void AdvancingFrontMesh::fillHole()
{
	map<int, bool> isOriginal_Vertex;
	map<int, bool> isOriginal_Face;
	double length_average = 0;

	setIsOriginalVertexArray(mesh, isOriginal_Vertex); // set Original Vertices
	setIsOriginalFaceArray(mesh, isOriginal_Face); // set Original Faces
	length_average = edgeLengthAverage(mesh); // calc edges average length

	int targethole_index;
	int filled_hole_count = 0;

	while (filled_hole_count < Unit_holes.size())
	{
		cout << "Ž���� ���� ���� : " << Unit_holes.size() << endl;
		cout << "ä�� ������ ���� : " << filled_hole_count << endl;
		cout << "�޿� �� �ִ� ������ index :  ";

		for (int i = 0; i < Unit_holes.size(); i++)
		{
			if (!Unit_holes[i].is_filled)
				cout << Unit_holes[i].hole_number << " ";
		}

		cout << endl << "�޿� ������ index�� �Է��Ͻʽÿ� (�޿��� ���� : -1) : ";

		cin >> targethole_index;

		if (targethole_index == -1)
			break;

		

#pragma region UseQuadrics
		////==============================Quadrics=================================================
		QuadricsFit q;
		//vector<allquadrics::data_pnw> quadrics_hole_vertices_data;
		//for (int i = 0; i < Unit_holes[targethole_index].hole_original_vertices.size(); i++)
		//{
		//	vec3 point(Unit_holes[targethole_index].hole_original_vertices[i].second[0]
		//		, Unit_holes[targethole_index].hole_original_vertices[i].second[1]
		//		, Unit_holes[targethole_index].hole_original_vertices[i].second[2]);
		//	vec3 normal(Unit_holes[targethole_index].original_vertices_normals[i].second[0]
		//		, Unit_holes[targethole_index].original_vertices_normals[i].second[1]
		//		, Unit_holes[targethole_index].original_vertices_normals[i].second[2]);

		//	quadrics_hole_vertices_data.push_back({ point, normal, 1 });
		//}

		//QuadricsFit quadricsFit;
		//vector<allquadrics::Quadric> qs;
		//allquadrics::Quadric q;

		// QuadricsFit.fitAllQuadricTypes(quadrics_hole_vertices_data);

		//cout << endl << "quadrics ���� (0 : general, 1 : rotationally symmetric, 2 : ) : ";

		//cin >> Quadrics_index;

		//bool useQuadrics = true;

		//if (Quadrics_index == -1)
		//	useQuadrics = false;

		////==============================Quadrics=================================================
#pragma endregion

		try
		{
			fillHoleMain(mesh, Unit_holes[targethole_index].hole_original_vertices,
				Unit_holes[targethole_index].angles, Unit_holes[targethole_index].minAngleVertexIndex, isOriginal_Vertex, length_average, q, false);
		}
		catch (std::exception& x)
		{
			saveMesh(mesh, "Error_" + to_string(targethole_index));
			cout << "���� �߻�, ä�� �� ���� Hole Ž��_" + targethole_index << endl;
			cout << "Error : " << x.what() << endl;
			break;
		}

		Unit_holes[targethole_index].new_Vertices = findNewVertices(mesh, Unit_holes[targethole_index], Unit_holes, isOriginal_Vertex);
		Unit_holes[targethole_index].new_Faces = findNewFaces(mesh, Unit_holes[targethole_index], Unit_holes, isOriginal_Face);

		findInvalidVertices(mesh, Unit_holes[targethole_index]);

		Unit_holes[targethole_index].is_filled = true;
		filled_hole_count++;

		mesh.garbage_collection();
		saveMesh(mesh, "result_" + to_string(targethole_index) + "_fillhole", true); // save result

		cout << "�۾� �Ϸ�" << endl << endl;
	}

	cout << "��� Hole Filling �Ϸ�" << endl;
}

void AdvancingFrontMesh::save(string filename)
{
	saveMesh(mesh, filename, true);
}


//============================================================OpenMesh============================



