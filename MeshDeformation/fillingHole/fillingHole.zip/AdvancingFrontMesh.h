#pragma once

#include "../MeshDisplay/MyTriMesh.h"

struct UnitHole
{
	int hole_number;
	bool is_filled;
	vector<pair<TriMesh::VertexHandle, TriMesh::Normal>> original_vertices_normals;
	vector<pair<TriMesh::VertexHandle, TriMesh::Point>> hole_original_vertices;
	vector<TriMesh::FaceHandle> original_Faces;
	vector<TriMesh::VertexHandle> new_Vertices;
	vector<TriMesh::FaceHandle> new_Faces;
	vector<double> angles;
	int minAngleVertexIndex;

	void eraseDuplicateOriginalFaces() {
		vector<TriMesh::FaceHandle>temp_originalFaces;
		map<TriMesh::FaceHandle, int> mapFaces;
		temp_originalFaces.resize(original_Faces.size());
		std::copy(original_Faces.begin(), original_Faces.end(), temp_originalFaces.begin());
		original_Faces.clear();
		for (int i = 0; i < temp_originalFaces.size(); i++)	{
			if (mapFaces.find(temp_originalFaces[i]) == mapFaces.end()) {
				mapFaces[temp_originalFaces[i]] = 1;
				original_Faces.push_back(temp_originalFaces[i]);
			}
			else
			{
				int k = 0;
				k++;
			}
		}
	}
};

class AdvancingFrontMesh
{
public:
	TriMesh mesh;
	vector<UnitHole> Unit_holes;

	//FillingHole();

	AdvancingFrontMesh(TriMesh _mesh);
	void findAllUnitHoles();
	void fillAllHoles();
	void fillHole();
	void save(string filename);
};

void saveMesh(TriMesh mesh, string name, bool resultSave = false);