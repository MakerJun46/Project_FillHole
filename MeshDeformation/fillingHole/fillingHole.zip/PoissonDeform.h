#pragma once

#include "../MeshDisplay/MyTriMesh.h"
#include "../fillingHole/AdvancingFrontMesh.h"

class PoissonDeform
{
public:
	void deform(TriMesh& mesh, vector<UnitHole> UnitHoles);
};